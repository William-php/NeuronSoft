import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baseboard',
  templateUrl: './baseboard.component.html',
  styleUrls: ['./baseboard.component.scss']
})
export class BaseboardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
